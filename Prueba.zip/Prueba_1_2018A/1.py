
archi=open('1.txt','r')
linea=archi.readline()

lista = []
lista = linea
for linea in lista:

    print(linea)



