def creartxt():
    archi=open('2.txt','w')
    archi.close()
creartxt()

cadenaDeTexto = 'abcd'
list(cadenaDeTexto)

lista = []
lista = cadenaDeTexto.replace(cadenaDeTexto,'dcba',4)

print(lista)